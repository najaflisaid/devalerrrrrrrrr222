import React, { useEffect, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { productService } from '../services/productService';
import { Product } from '../types';
import { useInView } from '../hooks/useInView';
import { getHomepageSections, HomepageSections, DEFAULT_HOMEPAGE_SECTIONS } from '../services/contentService';

const SignaturePiece3D: React.FC = () => {
  const { i18n } = useTranslation();
  const navigate = useNavigate();
  const { ref: sectionRef, inView } = useInView<HTMLElement>();
  const [product, setProduct] = useState<Product | null>(null);
  const [cfg, setCfg] = useState<HomepageSections['signature']>(DEFAULT_HOMEPAGE_SECTIONS.signature);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const [rot, setRot] = useState({ rx: 0, ry: 0 });

  useEffect(() => {
    (async () => {
      try {
        const sections = await getHomepageSections();
        setCfg(sections.signature);

        let p: Product | null = null;
        if (sections.signature.featuredProductId) {
          try {
            p = await productService.getById(sections.signature.featuredProductId);
          } catch (e) {
            console.warn('Signature featured product missing, using fallback');
          }
        }
        if (!p) {
          const list = await productService.getBestSellers(6);
          if (list && list.length > 0) p = list[0];
        }
        setProduct(p);
      } catch (err) {
        console.error('SignaturePiece3D: load error', err);
      }
    })();
  }, []);

  const handleMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = stageRef.current;
    if (!el) return;
    if (!window.matchMedia('(pointer: fine)').matches) return;
    const rect = el.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setRot({ rx: -y * 18, ry: x * 24 });
  };
  const handleLeave = () => setRot({ rx: 0, ry: 0 });

  if (!cfg.enabled || !product) return null;

  const lang = (i18n.language as 'az' | 'ru' | 'en') || 'az';
  const get = (f: { az: string; ru: string; en: string }) => f[lang] || f.az || f.en;

  const getName = (p: Product): string => {
    if (typeof p.name === 'string') return p.name;
    return p.name[lang] || p.name.az || p.name.en || '';
  };

  return (
    <section
      ref={sectionRef}
      className="relative pt-12 pb-16 md:pt-20 md:pb-24 overflow-hidden bg-white"
      data-testid="dv-signature-3d"
    >
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-2 gap-4 sm:gap-8 md:gap-16 items-center">
          {/* LEFT: text */}
          <div className={`order-1 dv-reveal ${inView ? 'is-in' : ''}`}>
            {/* Brand name (auto from product) */}
            {product.brand && (
              <div className="mb-2 md:mb-3 lg:mb-4">
                <span
                  className="dv-shimmer font-playfair font-semibold leading-none tracking-tight whitespace-nowrap select-none block"
                  style={{
                    fontSize: 'clamp(1.4rem, 5.5vw, 5rem)',
                    letterSpacing: '-0.01em',
                  }}
                  data-testid="dv-signature-brand-desktop"
                >
                  {product.brand}
                </span>
              </div>
            )}

            <div className="flex items-center mb-3 md:mb-5">
              <span className="inline-block w-6 md:w-10 h-[1px] bg-[#D4AF37]" />
              <span className="ml-2 md:ml-3 text-[8px] md:text-[10px] uppercase tracking-[0.3em] md:tracking-[0.4em] dv-shimmer font-semibold">
                {get(cfg.eyebrow)}
              </span>
            </div>
            <h2 className="font-playfair text-xl sm:text-3xl md:text-6xl lg:text-7xl font-light text-black leading-[1.05] tracking-tight mb-2 md:mb-5">
              {get(cfg.title)}
            </h2>
            <p className="text-black/60 text-[11px] sm:text-sm md:text-lg font-light leading-relaxed max-w-md mb-4 md:mb-10">
              {get(cfg.subtitle)}
            </p>

            <div className="border-t border-black/10 pt-3 md:pt-7">
              <p className="text-[8px] md:text-[10px] uppercase tracking-[0.25em] md:tracking-[0.35em] text-black/50 mb-1.5 md:mb-3">
                {get(cfg.pickLabel)}
              </p>

              {/* Product card */}
              <div className="mb-4 md:mb-7 md:flex md:items-end md:justify-between md:gap-6">
                <div className="min-w-0">
                  <h3 className="font-playfair text-sm sm:text-lg md:text-2xl font-medium text-black leading-tight truncate">
                    {getName(product)}
                  </h3>
                  <p className="mt-0.5 md:mt-1 text-[8px] md:text-[10px] uppercase tracking-[0.2em] md:tracking-[0.25em] text-black/40 font-mono">
                    Ref. {product.id?.slice(0, 8) || ''}
                  </p>
                </div>
                <div className="md:text-right flex-shrink-0 mt-2 md:mt-0">
                  <p className="text-[8px] md:text-[10px] uppercase tracking-[0.25em] md:tracking-[0.3em] text-black/40 mb-0.5">Qiymət</p>
                  <p className="font-playfair text-base sm:text-xl md:text-3xl font-light text-black leading-none">
                    {product.price?.toFixed(0)}
                    <span className="ml-1 text-[10px] sm:text-xs md:text-sm font-light tracking-wider text-black/60">AZN</span>
                  </p>
                </div>
              </div>

              <button
                onClick={() => navigate(`/product/${product.id}`)}
                className="dv-signature-cta group inline-flex items-center justify-center gap-2 md:gap-3 px-3 sm:px-5 md:px-7 py-2 sm:py-2.5 md:py-3.5 border border-black bg-white hover:bg-black hover:text-white text-[8px] sm:text-[10px] md:text-[11px] uppercase tracking-[0.2em] sm:tracking-[0.28em] md:tracking-[0.32em] font-medium text-black transition-all duration-500"
                data-testid="dv-signature-cta"
              >
                <span>{get(cfg.ctaLabel)}</span>
                <span className="transition-transform duration-500 group-hover:translate-x-1.5 text-xs md:text-base leading-none">→</span>
              </button>
            </div>
          </div>

          {/* RIGHT: 3D stage */}
          <div
            ref={stageRef}
            className={`order-2 relative aspect-square max-w-[420px] md:max-w-[520px] mx-auto w-full dv-reveal ${inView ? 'is-in' : ''} dv-reveal-delay-2`}
            onMouseMove={handleMove}
            onMouseLeave={handleLeave}
            style={{ perspective: '1200px' }}
          >
            {/* Soft shadow beneath */}
            <div
              className="absolute bottom-[8%] left-1/2 -translate-x-1/2 w-[60%] h-8 rounded-full pointer-events-none"
              style={{
                background: 'radial-gradient(ellipse, rgba(0,0,0,0.18), transparent 70%)',
                filter: 'blur(8px)',
              }}
              aria-hidden="true"
            />

            <div
              className="absolute inset-[10%] sm:inset-[15%] md:inset-[18%] flex items-center justify-center"
              style={{
                transformStyle: 'preserve-3d',
                transform: `rotateX(${rot.rx}deg) rotateY(${rot.ry}deg) translateZ(60px)`,
                transition: 'transform 400ms cubic-bezier(.2,.8,.2,1)',
              }}
            >
              <div className="dv-piece-float w-full h-full">
                <img
                  src={product.images?.[0] || product.imageUrl}
                  alt={getName(product)}
                  className="w-full h-full object-contain cursor-pointer"
                  onClick={() => navigate(`/product/${product.id}`)}
                  style={{
                    filter: 'drop-shadow(0 30px 50px rgba(0,0,0,0.28))',
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SignaturePiece3D;
