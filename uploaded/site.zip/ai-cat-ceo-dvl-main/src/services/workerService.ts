import {
  collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc,
  addDoc, query, where, orderBy, Timestamp, onSnapshot, limit,
  writeBatch,
} from 'firebase/firestore';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage, getSecondaryAuth } from '../lib/firebase';
import {
  createUserWithEmailAndPassword, signOut as fbSignOut,
  signInWithEmailAndPassword, updatePassword,
} from 'firebase/auth';
import type {
  Worker, AttendanceEntry, Fine, Reward, SalesEntry,
  WorkerRequest, RequestStatus, WorkerNotification, Position, Branch, Training, BranchLeaderboardEntry, PerformanceBreakdown,
} from '../types/worker';

const WORKERS = 'workers';
const POSITIONS = 'worker_positions';
const BRANCHES = 'worker_branches';
const TRAININGS = 'worker_trainings';
const ATTENDANCE = 'worker_attendance';
const FINES = 'worker_fines';
const REWARDS = 'worker_rewards';
const SALES = 'worker_sales';
const REQUESTS = 'worker_requests';
const NOTIFICATIONS = 'worker_notifications';

const TZ = 'Asia/Baku';

// Bakıdakı tarixi YYYY-MM-DD formatında qaytarır
const todayStr = () => {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(new Date());
  return parts; // en-CA verir YYYY-MM-DD
};
const nowIso = () => new Date().toISOString();

// Bakı saatına görə YYYY-MM (ay) qaytarır
const bakuMonthYM = (d = new Date()) => {
  const y = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric' }).format(d);
  const m = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, month: '2-digit' }).format(d);
  return `${y}-${m}`;
};

// Bakı saatına görə günün tarixinin günü (1-31)
const bakuDay = (d = new Date()) => {
  return Number(new Intl.DateTimeFormat('en-CA', { timeZone: TZ, day: '2-digit' }).format(d));
};

// Bakı saatına görə saat (0-23)
const bakuHour = (iso: string) => {
  return Number(new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', hour12: false }).format(new Date(iso)));
};

// ───────────────────── Workers ─────────────────────
export const createWorker = async (
  email: string,
  password: string,
  data: Omit<Worker, 'id' | 'email' | 'createdAt' | 'rating' | 'isActive' | 'monthlyTarget'> & {
    rating?: number; isActive?: boolean; monthlyTarget?: number;
  }
): Promise<Worker> => {
  // Use secondary auth so the admin's session is not affected
  const sAuth = getSecondaryAuth();
  const cred = await createUserWithEmailAndPassword(sAuth, email, password);
  const uid = cred.user.uid;
  await fbSignOut(sAuth);

  const worker: Worker = {
    id: uid,
    email,
    name: data.name,
    surname: data.surname,
    photo: data.photo || '',
    position: data.position,
    branch: data.branch || '',
    hireDate: data.hireDate,
    contractStart: data.contractStart,
    contractEnd: data.contractEnd,
    rating: data.rating ?? 5,
    isActive: data.isActive ?? true,
    monthlyTarget: data.monthlyTarget ?? 0,
    loginPassword: password, // admin görə bilsin (Firebase Auth-da əsas şifrə bu, sonradan dəyişdirilə bilməz)
    createdAt: nowIso(),
  };
  await setDoc(doc(db, WORKERS, uid), worker);
  return worker;
};

export const getWorker = async (id: string): Promise<Worker | null> => {
  const snap = await getDoc(doc(db, WORKERS, id));
  return snap.exists() ? (snap.data() as Worker) : null;
};

export const getWorkerByEmail = async (email: string): Promise<Worker | null> => {
  const q = query(collection(db, WORKERS), where('email', '==', email), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  return snap.docs[0].data() as Worker;
};

export const listWorkers = async (): Promise<Worker[]> => {
  const snap = await getDocs(query(collection(db, WORKERS), orderBy('createdAt', 'desc')));
  const workers = snap.docs.map(d => d.data() as Worker);
  // Avtomatik aylıq hədəf rollover — ay 1-i olduqda hər işçinin hədəfi avtomatik
  // yeni aya kopyalanır (admin yenidən daxil etməyə ehtiyac duymur).
  // Idempotent: artıq edilibsə heç bir yazı baş vermir.
  try {
    await rolloverTargetsToCurrentMonthIfNeeded(workers);
  } catch (e) {
    // Rollover səhvi əsas siyahını blok etməsin
    console.warn('rolloverTargets warning:', e);
  }
  return workers;
};

/**
 * rolloverTargetsToCurrentMonthIfNeeded
 *
 * Cari ay üçün `targetsHistory[currentYM]` yoxdursa, əvvəlki ən son hədəfi
 * (əvvəlcə `targetsHistory`-dən, sonra `monthlyTarget`-dən) götürür və cari aya
 * yazır. Beləliklə yeni ay başlayanda admin yenidən eyni rəqəmi yazmağa məcbur
 * deyil — köhnə hədəf avtomatik daşınır. Admin sonradan açıb dəyişə bilər.
 *
 * Atomik writeBatch — bir neçə işçi olsa belə tək batch-də yazılır.
 * Yan effekt: işçi obyektləri inplace yenilənir ki, çağıran funksiya təzə dəyəri
 * dərhal görsün (re-fetch lazım deyil).
 */
export const rolloverTargetsToCurrentMonthIfNeeded = async (workers: Worker[]): Promise<number> => {
  const ym = monthYM();
  const needs: Array<{ id: string; target: number; worker: Worker }> = [];

  for (const w of workers) {
    if (!w?.id) continue;
    const th: Record<string, number> = (w as any).targetsHistory || {};
    if (typeof th[ym] === 'number') continue; // artıq mövcuddur — atla

    // Əvvəlki ən son hədəfi tap
    const pastMonths = Object.keys(th).filter((k) => k < ym).sort().reverse();
    let prevTarget = 0;
    let prevSource: 'history' | 'monthlyTarget' | null = null;
    if (pastMonths.length > 0) {
      prevTarget = Number(th[pastMonths[0]]) || 0;
      prevSource = 'history';
    } else if (typeof w.monthlyTarget === 'number' && w.monthlyTarget > 0) {
      prevTarget = w.monthlyTarget;
      prevSource = 'monthlyTarget';
    }

    if (prevSource && prevTarget > 0) {
      needs.push({ id: w.id, target: prevTarget, worker: w });
    }
  }

  if (needs.length === 0) return 0;

  // Firestore atomik batch (max 500 op)
  const BATCH_LIMIT = 450;
  for (let i = 0; i < needs.length; i += BATCH_LIMIT) {
    const chunk = needs.slice(i, i + BATCH_LIMIT);
    const batch = writeBatch(db);
    for (const n of chunk) {
      batch.update(doc(db, WORKERS, n.id), {
        [`targetsHistory.${ym}`]: n.target,
        // monthlyTarget cari ay üçün ardıcıllıq saxlamaq üçün də yenilənir
        monthlyTarget: n.target,
      });
    }
    await batch.commit();
    // İnplace dəyişiklik — caller təzə fetch etmədən görə bilsin
    chunk.forEach((n) => {
      const w: any = n.worker;
      w.targetsHistory = { ...(w.targetsHistory || {}), [ym]: n.target };
      w.monthlyTarget = n.target;
    });
  }
  return needs.length;
};

export const updateWorker = async (id: string, patch: Partial<Worker>) => {
  await updateDoc(doc(db, WORKERS, id), patch as any);
};

export const deleteWorker = async (id: string) => {
  await deleteDoc(doc(db, WORKERS, id));
};

// İşçinin Firebase Auth şifrəsini dəyişdirir (köhnə şifrəni bilməklə)
// Əgər oldPassword yoxdursa və ya səhvdirsə xəta atılır.
export const changeWorkerPassword = async (
  email: string,
  oldPassword: string,
  newPassword: string
): Promise<void> => {
  if (!oldPassword) {
    throw new Error('Köhnə şifrə qeydiyyatda yoxdur. Bu işçinin Firebase Auth şifrəsi avtomatik dəyişilə bilməz. Onu silib yenidən yaradın.');
  }
  const sAuth = getSecondaryAuth();
  const cred = await signInWithEmailAndPassword(sAuth, email, oldPassword);
  await updatePassword(cred.user, newPassword);
  await fbSignOut(sAuth);
};

export const uploadWorkerPhoto = async (workerId: string, file: File): Promise<string> => {
  const path = `workers/${workerId}/${Date.now()}_${file.name}`;
  const r = storageRef(storage, path);
  await uploadBytes(r, file);
  return await getDownloadURL(r);
};

export const uploadRequestAttachment = async (workerId: string, file: File): Promise<string> => {
  const path = `workers/${workerId}/requests/${Date.now()}_${file.name}`;
  const r = storageRef(storage, path);
  await uploadBytes(r, file);
  return await getDownloadURL(r);
};

// ───────────────────── Attendance ─────────────────────
export const startWork = async (workerId: string): Promise<AttendanceEntry> => {
  const date = todayStr();
  const id = `${workerId}_${date}`;
  const ref = doc(db, ATTENDANCE, id);
  const existing = await getDoc(ref);
  if (existing.exists() && (existing.data() as AttendanceEntry).startTime) {
    return existing.data() as AttendanceEntry;
  }
  const entry: AttendanceEntry = { id, workerId, date, startTime: nowIso() };
  await setDoc(ref, entry);
  return entry;
};

export const endWork = async (workerId: string): Promise<AttendanceEntry | null> => {
  const date = todayStr();
  const id = `${workerId}_${date}`;
  const ref = doc(db, ATTENDANCE, id);
  const snap = await getDoc(ref);
  if (!snap.exists()) return null;
  const e = snap.data() as AttendanceEntry;
  if (!e.startTime) return null;
  const endTime = nowIso();
  const durationMs = new Date(endTime).getTime() - new Date(e.startTime).getTime();
  const updated: AttendanceEntry = { ...e, endTime, durationMs };
  await setDoc(ref, updated);
  return updated;
};

export const getTodayAttendance = async (workerId: string): Promise<AttendanceEntry | null> => {
  const id = `${workerId}_${todayStr()}`;
  const snap = await getDoc(doc(db, ATTENDANCE, id));
  return snap.exists() ? (snap.data() as AttendanceEntry) : null;
};

export const listAttendance = async (workerId: string, days = 60): Promise<AttendanceEntry[]> => {
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
  // Composite index tələbindən qaçmaq üçün yalnız workerId üzrə sorğu, tarix in-memory filtrlənir.
  const q = query(collection(db, ATTENDANCE), where('workerId', '==', workerId));
  const snap = await getDocs(q);
  return snap.docs
    .map(d => d.data() as AttendanceEntry)
    .filter(a => a.date >= since)
    .sort((a, b) => b.date.localeCompare(a.date));
};

export const listAllAttendanceToday = async (): Promise<AttendanceEntry[]> => {
  const q = query(collection(db, ATTENDANCE), where('date', '==', todayStr()));
  const snap = await getDocs(q);
  return snap.docs.map(d => d.data() as AttendanceEntry);
};

// ───────────────────── Fines / Rewards ─────────────────────
export const addFine = async (data: Omit<Fine, 'id'>): Promise<Fine> => {
  const ref = await addDoc(collection(db, FINES), data);
  return { id: ref.id, ...data };
};

export const listFines = async (workerId: string): Promise<Fine[]> => {
  const q = query(collection(db, FINES), where('workerId', '==', workerId));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...(d.data() as Omit<Fine, 'id'>) }))
    .sort((a, b) => b.date.localeCompare(a.date));
};

export const deleteFine = async (id: string) => deleteDoc(doc(db, FINES, id));

export const addReward = async (data: Omit<Reward, 'id'>): Promise<Reward> => {
  const ref = await addDoc(collection(db, REWARDS), data);
  return { id: ref.id, ...data };
};

export const listRewards = async (workerId: string): Promise<Reward[]> => {
  const q = query(collection(db, REWARDS), where('workerId', '==', workerId));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...(d.data() as Omit<Reward, 'id'>) }))
    .sort((a, b) => b.date.localeCompare(a.date));
};

export const deleteReward = async (id: string) => deleteDoc(doc(db, REWARDS, id));

export const updateReward = async (id: string, patch: Partial<Reward>) => {
  await updateDoc(doc(db, REWARDS, id), patch as any);
};

export const updateFine = async (id: string, patch: Partial<Fine>) => {
  await updateDoc(doc(db, FINES, id), patch as any);
};

// ───────────────────── Sales (for performance) ─────────────────────
export const addSale = async (data: Omit<SalesEntry, 'id'>): Promise<SalesEntry> => {
  const ref = await addDoc(collection(db, SALES), data);
  return { id: ref.id, ...data };
};

export const listSales = async (workerId: string, monthYM?: string): Promise<SalesEntry[]> => {
  const q = query(collection(db, SALES), where('workerId', '==', workerId));
  const snap = await getDocs(q);
  const items = snap.docs.map(d => ({ id: d.id, ...(d.data() as Omit<SalesEntry, 'id'>) }));
  if (monthYM) return items.filter(s => s.date.startsWith(monthYM));
  return items.sort((a, b) => b.date.localeCompare(a.date));
};

// ───────────────────── Requests ─────────────────────
export const submitRequest = async (
  data: Omit<WorkerRequest, 'id' | 'status' | 'createdAt'>
): Promise<WorkerRequest> => {
  const payload = { ...data, status: 'sent' as RequestStatus, createdAt: nowIso() };
  const ref = await addDoc(collection(db, REQUESTS), payload);
  return { id: ref.id, ...payload };
};

export const listRequests = async (workerId?: string): Promise<WorkerRequest[]> => {
  const q = workerId
    ? query(collection(db, REQUESTS), where('workerId', '==', workerId))
    : query(collection(db, REQUESTS));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...(d.data() as Omit<WorkerRequest, 'id'>) }))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
};

export const updateRequestStatus = async (
  id: string, status: RequestStatus, adminResponse?: string
) => {
  await updateDoc(doc(db, REQUESTS, id), {
    status, adminResponse: adminResponse || '', updatedAt: nowIso(),
  });
};

export const deleteRequest = async (id: string) => deleteDoc(doc(db, REQUESTS, id));

// ───────────────────── Notifications ─────────────────────
export const sendNotification = async (workerId: string, message: string) => {
  const data: Omit<WorkerNotification, 'id'> = {
    workerId, message, read: false, createdAt: nowIso(),
  };
  const ref = await addDoc(collection(db, NOTIFICATIONS), data);
  return { id: ref.id, ...data } as WorkerNotification;
};

export const listNotifications = async (workerId: string): Promise<WorkerNotification[]> => {
  const q = query(collection(db, NOTIFICATIONS), where('workerId', '==', workerId));
  const snap = await getDocs(q);
  const all = snap.docs.map(d => ({ id: d.id, ...(d.data() as Omit<WorkerNotification, 'id'>) }));

  // 30 gündən köhnə bildirişləri filter et (göstərmə)
  const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
  const cutoff = Date.now() - THIRTY_DAYS_MS;

  // Avtomatik fiziki silinmə yalnız 7 gündən bir baş verir (Firestore yazma kvotasını qoruyaq).
  // Açar localStorage-də saxlanır.
  try {
    const ck = `worker_notif_cleanup_${workerId}`;
    const last = Number(localStorage.getItem(ck) || 0);
    const oneWeek = 7 * 24 * 60 * 60 * 1000;
    if (Date.now() - last > oneWeek) {
      const expired = all.filter(n => {
        const t = new Date(n.createdAt).getTime();
        return Number.isFinite(t) && t < cutoff;
      });
      if (expired.length > 0) {
        // Maksimum 20 silinmə bir defədə — kvotanı qorumaq üçün
        const toDelete = expired.slice(0, 20);
        Promise.all(toDelete.map(n => deleteDoc(doc(db, NOTIFICATIONS, n.id)))).catch(() => {});
      }
      localStorage.setItem(ck, String(Date.now()));
    }
  } catch { /* ignore */ }

  return all
    .filter(n => {
      const t = new Date(n.createdAt).getTime();
      return !Number.isFinite(t) || t >= cutoff;
    })
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
};

export const markNotificationRead = async (id: string) => {
  await updateDoc(doc(db, NOTIFICATIONS, id), { read: true });
};

// ───────────────────── Helpers ─────────────────────
export const monthYM = (d = new Date()) => bakuMonthYM(d);

export const daysSince = (iso: string): number => {
  return Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
};

export const computeAttendancePercent = async (workerId: string): Promise<number> => {
  const ym = monthYM();
  const items = await listAttendance(workerId, 31);
  const monthDays = items.filter(a => a.date.startsWith(ym) && a.startTime);
  const workingDaysSoFar = bakuDay(); // bu günün tarixi (Bakı vaxtı ilə)
  const present = monthDays.length;
  return workingDaysSoFar === 0 ? 0 : Math.min(100, Math.round((present / workingDaysSoFar) * 100));
};

// ───────────────────── Positions ─────────────────────
export const listPositions = async (): Promise<Position[]> => {
  const snap = await getDocs(collection(db, POSITIONS));
  return snap.docs
    .map(d => ({ id: d.id, ...(d.data() as Omit<Position, 'id'>) }))
    .sort((a, b) => a.name.localeCompare(b.name, 'az'));
};

export const addPosition = async (name: string): Promise<Position> => {
  const data = { name: name.trim(), createdAt: nowIso() };
  const ref = await addDoc(collection(db, POSITIONS), data);
  return { id: ref.id, ...data };
};

export const updatePosition = async (id: string, name: string) => {
  await updateDoc(doc(db, POSITIONS, id), { name: name.trim() });
};

export const deletePosition = async (id: string) => deleteDoc(doc(db, POSITIONS, id));

// ───────────────────── Monthly total + salesHistory helper ─────────────────────
export const setMonthlyTotal = async (workerId: string, total: number, ym: string) => {
  // salesHistory.${ym}-i nested update ilə yenilə (digər ayları silmədən)
  await updateDoc(doc(db, WORKERS, workerId), {
    monthlyTotalSales: total,
    monthlyTotalMonth: ym,
    [`salesHistory.${ym}`]: total,
  } as any);
};

// İstənilən ay üçün satış tarixçəsini saxla / silməsi (12 aylıq qrafik üçün).
// Əgər ay cari aydırsa, monthlyTotalSales/Month pointer-ləri də yenilənir.
export const setMonthlySalesHistory = async (workerId: string, ym: string, amount: number) => {
  const patch: any = { [`salesHistory.${ym}`]: amount };
  if (ym === monthYM()) {
    patch.monthlyTotalSales = amount;
    patch.monthlyTotalMonth = ym;
  }
  await updateDoc(doc(db, WORKERS, workerId), patch);
};

// ───────────────────── Qaytarılmalar (Returns) ─────────────────────
/**
 * setMonthlyReturnsHistory — verilmiş ay üçün qaytarılma məbləğini saxla.
 * Cari aydırsa, `monthlyTotalReturns` pointer-i də yenilənir.
 */
export const setMonthlyReturnsHistory = async (workerId: string, ym: string, amount: number) => {
  const patch: any = { [`returnsHistory.${ym}`]: amount };
  if (ym === monthYM()) {
    patch.monthlyTotalReturns = amount;
  }
  await updateDoc(doc(db, WORKERS, workerId), patch);
};

/** Xalis satış = ümumi satış − qaytarılma */
export const netSalesForMonth = (worker: Worker, ym: string): number => {
  const isCurrent = worker.monthlyTotalMonth === ym;
  const sales =
    isCurrent && typeof worker.monthlyTotalSales === 'number'
      ? worker.monthlyTotalSales
      : (worker.salesHistory?.[ym] ?? 0);
  const returns =
    isCurrent && typeof worker.monthlyTotalReturns === 'number'
      ? worker.monthlyTotalReturns
      : (worker.returnsHistory?.[ym] ?? 0);
  return Math.max(0, (sales || 0) - (returns || 0));
};

// ───────────────────── Bonus Tier System ─────────────────────
const BONUS_TIERS_COLL = 'worker_bonus_settings';
const BONUS_TIERS_DOC = 'default';

export type BonusTier = {
  /** Aşağı hədd (daxil) */
  from: number;
  /** Yuxarı hədd (daxil deyil) — null = sonsuz */
  to: number | null;
  /** Faiz dərəcəsi (məs. 2 = 2%) */
  percent: number;
};

export type BonusMode = 'flat' | 'cumulative';

export interface BonusSettings {
  /** Tier-lər from artan sıra ilə */
  tiers: BonusTier[];
  /**
   * 'flat' — xalis satış hansı tier-ə düşürsə, BÜTÜN məbləğ o tier-in faizi ilə hesablanır.
   *   məs. tier-lər: 0-10000=1%, 10000+=2%, xalis satış=12000 → bonus = 12000×2% = 240
   * 'cumulative' — hər tier-in payı ayrıca hesablanıb cəmlənir.
   *   məs. xalis satış=12000 → 10000×1% + 2000×2% = 100 + 40 = 140
   */
  mode: BonusMode;
  updatedAt?: string;
}

const DEFAULT_BONUS_SETTINGS: BonusSettings = {
  tiers: [
    { from: 0, to: 10000, percent: 1 },
    { from: 10000, to: 50000, percent: 2 },
    { from: 50000, to: null, percent: 3 },
  ],
  mode: 'flat',
};

export const getBonusSettings = async (): Promise<BonusSettings> => {
  try {
    const ref = doc(db, BONUS_TIERS_COLL, BONUS_TIERS_DOC);
    const snap = await getDoc(ref);
    if (!snap.exists()) return DEFAULT_BONUS_SETTINGS;
    const data = snap.data() as any;
    const tiers = Array.isArray(data?.tiers) ? data.tiers : DEFAULT_BONUS_SETTINGS.tiers;
    const mode: BonusMode = data?.mode === 'cumulative' ? 'cumulative' : 'flat';
    return { tiers, mode, updatedAt: data?.updatedAt };
  } catch {
    return DEFAULT_BONUS_SETTINGS;
  }
};

export const saveBonusSettings = async (settings: BonusSettings): Promise<void> => {
  // Tier-ləri normalize et: from artan sıra, valid rəqəmlər, percent >=0
  const tiers = (settings.tiers || [])
    .map((t) => ({
      from: Math.max(0, Number(t.from) || 0),
      to: t.to === null || t.to === undefined || t.to === ('' as any) ? null : Math.max(0, Number(t.to) || 0),
      percent: Math.max(0, Number(t.percent) || 0),
    }))
    .filter((t) => t.percent > 0 || t.from > 0 || (t.to !== null && t.to > 0))
    .sort((a, b) => a.from - b.from);
  await setDoc(doc(db, BONUS_TIERS_COLL, BONUS_TIERS_DOC), {
    tiers,
    mode: settings.mode === 'cumulative' ? 'cumulative' : 'flat',
    updatedAt: nowIso(),
  });
};

/**
 * computeBonus — xalis satış məbləği və tier-ə görə bonus hesabla.
 *
 * @param netSales Xalis satış (satış − qaytarılma)
 * @param settings Bonus parametrləri
 * @returns Bonus AZN ilə (yuvarlaqlaşdırılmış 2 onluq)
 */
export const computeBonus = (netSales: number, settings: BonusSettings): {
  bonus: number;
  appliedTier: BonusTier | null;
  breakdown: Array<{ tier: BonusTier; amountInTier: number; bonusInTier: number }>;
} => {
  const n = Math.max(0, Number(netSales) || 0);
  const tiers = (settings.tiers || []).slice().sort((a, b) => a.from - b.from);
  if (tiers.length === 0 || n <= 0) {
    return { bonus: 0, appliedTier: null, breakdown: [] };
  }

  if (settings.mode === 'cumulative') {
    let remaining = n;
    let bonus = 0;
    const breakdown: Array<{ tier: BonusTier; amountInTier: number; bonusInTier: number }> = [];
    for (const tier of tiers) {
      const high = tier.to === null ? Infinity : tier.to;
      const low = tier.from;
      const segment = Math.max(0, Math.min(high, n) - low);
      if (segment > 0) {
        const tBonus = (segment * tier.percent) / 100;
        bonus += tBonus;
        breakdown.push({ tier, amountInTier: segment, bonusInTier: round2(tBonus) });
      }
      remaining -= segment;
      if (remaining <= 0) break;
    }
    return {
      bonus: round2(bonus),
      appliedTier: tiers[tiers.length - 1],
      breakdown,
    };
  }

  // Flat mode — xalis satış hansı tier-ə düşür?
  let applied: BonusTier | null = null;
  for (const tier of tiers) {
    const high = tier.to === null ? Infinity : tier.to;
    if (n >= tier.from && n < high) {
      applied = tier;
      break;
    }
  }
  // Yuxarı sınır xaricindəsə son tier
  if (!applied && n >= tiers[tiers.length - 1].from) applied = tiers[tiers.length - 1];

  const bonus = applied ? round2((n * applied.percent) / 100) : 0;
  return {
    bonus,
    appliedTier: applied,
    breakdown: applied ? [{ tier: applied, amountInTier: n, bonusInTier: bonus }] : [],
  };
};

const round2 = (n: number) => Math.round(n * 100) / 100;

// ───────────────────── Branches (Filiallar) ─────────────────────
export const listBranches = async (): Promise<Branch[]> => {
  const snap = await getDocs(collection(db, BRANCHES));
  return snap.docs
    .map(d => ({ id: d.id, ...(d.data() as Omit<Branch, 'id'>) }))
    .sort((a, b) => a.name.localeCompare(b.name, 'az'));
};

export const addBranch = async (name: string): Promise<Branch> => {
  const data = { name: name.trim(), createdAt: nowIso() };
  const ref = await addDoc(collection(db, BRANCHES), data);
  return { id: ref.id, ...data };
};

export const updateBranch = async (id: string, name: string) => {
  await updateDoc(doc(db, BRANCHES, id), { name: name.trim() });
};

export const deleteBranch = async (id: string) => deleteDoc(doc(db, BRANCHES, id));

// ───────────────────── Trainings (Təlimlər) ─────────────────────
export const listTrainings = async (): Promise<Training[]> => {
  const snap = await getDocs(collection(db, TRAININGS));
  return snap.docs
    .map(d => ({ id: d.id, ...(d.data() as Omit<Training, 'id'>) }))
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
};

export const addTraining = async (data: Omit<Training, 'id' | 'createdAt'>): Promise<Training> => {
  const payload = { ...data, createdAt: nowIso() };
  const ref = await addDoc(collection(db, TRAININGS), payload);
  return { id: ref.id, ...payload };
};

export const updateTraining = async (id: string, patch: Partial<Training>) => {
  await updateDoc(doc(db, TRAININGS, id), patch as any);
};

export const deleteTraining = async (id: string) => deleteDoc(doc(db, TRAININGS, id));

// ───────────────────── Vacation reset ─────────────────────
// Admin işçinin məzuniyyətə çıxdığını qeyd edib sayğacı sıfırlayır → 6 ay yenidən hesablanır.
export const resetVacation = async (workerId: string) => {
  await updateDoc(doc(db, WORKERS, workerId), { vacationResetAt: nowIso() } as any);
};

// ───────────────────── Birthday greeting ─────────────────────
// İşçi giriş etdiyində dashboard çağırır. Bugün ad-günüdürsə və hələ tebrik bildirişi
// göndərilməyibsə, bildiriş yaradır və işarələyir.
export const ensureBirthdayGreeting = async (worker: Worker): Promise<void> => {
  if (!worker.birthDate) return;
  const today = new Date();
  const todayMD = `${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  const bd = new Date(worker.birthDate);
  if (Number.isNaN(bd.getTime())) return;
  const bdMD = `${String(bd.getMonth() + 1).padStart(2, '0')}-${String(bd.getDate()).padStart(2, '0')}`;
  if (todayMD !== bdMD) return;
  if (worker.birthdayGreetedYear === today.getFullYear()) return;

  await sendNotification(
    worker.id,
    `🎉 Ad gününüz mübarək, ${worker.name}!\n\nDe Valeur ailəsi olaraq sizi səmimi qəlbdən təbrik edirik. Sağlam, uğurlu və xoşbəxt bir il arzulayırıq!`
  );
  await updateDoc(doc(db, WORKERS, worker.id), { birthdayGreetedYear: today.getFullYear() } as any);
};

// ───────────────────── Performance / Rating ─────────────────────
// Reytinq əmsalları:
//   - 85%-i aylıq satış hədəfinə görə
//   - +15 bonus hədəfi vuranda
//   - hər mükafata +5 (max +20)
//   - hər cəriməyə −8 (max −40)
//   - Davamiyyət və icazə nəzərə alınmır
//
// Aybaşı (carryover) qaydası:
//   Yeni ay başladıqda və admin hələ cari ay üçün heç bir məlumat (satış, cərimə, mükafat)
//   daxil etməyibsə, reytinq KEÇƏN AYın göstəricilərinə görə qalır. Cari ayda ilk məlumat
//   daxil olduqda dərhal cari aya keçir və faiz dəyişir.

export const computePerformance = async (worker: Worker): Promise<PerformanceBreakdown> => {
  const ym = monthYM();
  const [fines, rewards, sales] = await Promise.all([
    listFines(worker.id),
    listRewards(worker.id),
    listSales(worker.id, ym),
  ]);

  // Cari ay göstəriciləri — XALIS satış (returns çıxılır)
  const monthSales = sales.reduce((s, x) => s + (x.amount || 0), 0);
  const adminTotalThisMonth = worker.monthlyTotalMonth === ym && typeof worker.monthlyTotalSales === 'number';
  const monthFinesCount = fines.filter(f => (f.date || '').startsWith(ym)).length;
  const monthRewardsCount = rewards.filter(r => (r.date || '').startsWith(ym)).length;

  // Cari ayda hər hansı bir aktivlik var?
  const hasCurrentMonthActivity =
    adminTotalThisMonth || monthSales > 0 || monthFinesCount > 0 || monthRewardsCount > 0;

  // Hesablanacaq dövrü təyin edirik (cari ay vs. ən son fəal ay)
  let evalSalesTotal = adminTotalThisMonth ? netSalesForMonth(worker, ym) : monthSales;
  let evalFinesCount = monthFinesCount;
  let evalRewardsCount = monthRewardsCount;

  if (!hasCurrentMonthActivity) {
    // Keçmişdən ən son aktiv ayı tapırıq
    const history = worker.salesHistory || {};
    const months = Object.keys(history).sort().reverse();
    const lastMonth = months[0] || worker.monthlyTotalMonth || '';
    if (lastMonth) {
      evalSalesTotal = netSalesForMonth(worker, lastMonth);
      evalFinesCount = fines.filter(f => (f.date || '').startsWith(lastMonth)).length;
      evalRewardsCount = rewards.filter(r => (r.date || '').startsWith(lastMonth)).length;
    }
  }

  const target = worker.monthlyTarget || 0;

  // Sales score (ümumi reytinqin 85%-i)
  // Düzgün hesablama:
  //   • Hədəf təyin edilibsə: faktiki satışlar / hədəf %
  //   • Hədəfsiz, satış var: 70% baza (heç bir hədəfə uyğunlaşa bilməz)
  //   • Hədəfsiz, satış yox: 0% (heç bir məlumat yoxdur)
  let salesScore = 0;
  if (target > 0) {
    salesScore = Math.min(100, (evalSalesTotal / target) * 100);
  } else if (evalSalesTotal > 0) {
    salesScore = 70;
  } else {
    salesScore = 0;
  }

  const hitBonus = (target > 0 && evalSalesTotal >= target) ? 15 : 0;
  const finesPenalty = -Math.min(40, evalFinesCount * 8);
  const rewardsBonus = Math.min(20, evalRewardsCount * 5);

  const total = Math.max(0, Math.min(100, Math.round(
    salesScore * 0.85 +
    hitBonus +
    rewardsBonus +
    finesPenalty
  )));

  return {
    salesScore: Math.round(salesScore),
    hitBonus,
    finesPenalty,
    rewardsBonus,
    total,
  };
};

// İş stajı — illər və aylar
export const computeExperience = (hireDate: string): { years: number; months: number; days: number; label: string } => {
  if (!hireDate) return { years: 0, months: 0, days: 0, label: '—' };
  const start = new Date(hireDate);
  const now = new Date();
  let years = now.getFullYear() - start.getFullYear();
  let months = now.getMonth() - start.getMonth();
  let days = now.getDate() - start.getDate();
  if (days < 0) {
    months -= 1;
    const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    days += prevMonth.getDate();
  }
  if (months < 0) { years -= 1; months += 12; }
  const parts: string[] = [];
  if (years > 0) parts.push(`${years} il`);
  if (months > 0) parts.push(`${months} ay`);
  if (years === 0 && months === 0) parts.push(`${Math.max(0, days)} gün`);
  return { years, months, days, label: parts.join(' ') || '0 gün' };
};

// ───────────────────── Leaderboard (monthly total sales) ─────────────────────
export interface LeaderboardEntry {
  workerId: string;
  name: string;
  surname: string;
  photo?: string;
  position: string;
  branch?: string;
  rank: number;
  total: number;        // sales total used for ranking
  fromMonth: string;    // hansı aydan götürülüb
  hasTotal: boolean;
  /** Performance əmsalı (0-100) — sales score, hədəf bonus, mükafat və cərimə əsasında hesablanır */
  performanceScore: number;
}

// Helper: ən son mövcud XALIS SATIŞ total-ını və ayını qaytarır.
// Cari ay üçün admin daxil etmişsə cari ay götürür; yoxsa salesHistory-dən ən son ayı seçir.
// Xalis = satış − qaytarılma (returns).
const lastTotalForWorker = (w: Worker, currentYM: string): { total: number; fromMonth: string; hasTotal: boolean } => {
  if (w.monthlyTotalMonth === currentYM && typeof w.monthlyTotalSales === 'number') {
    return { total: netSalesForMonth(w, currentYM), fromMonth: currentYM, hasTotal: true };
  }
  const history = w.salesHistory || {};
  const months = Object.keys(history).sort().reverse(); // ən yeni öncə
  if (months.length > 0) {
    const m = months[0];
    return { total: netSalesForMonth(w, m), fromMonth: m, hasTotal: true };
  }
  // Fallback: bəlkə monthlyTotalSales var amma ayı keçmişdir
  if (typeof w.monthlyTotalSales === 'number' && w.monthlyTotalMonth) {
    return { total: netSalesForMonth(w, w.monthlyTotalMonth), fromMonth: w.monthlyTotalMonth, hasTotal: true };
  }
  return { total: 0, fromMonth: '', hasTotal: false };
};

export const getMonthlyLeaderboard = async (): Promise<LeaderboardEntry[]> => {
  const ym = monthYM();
  const workers = await listWorkers();
  const active = workers.filter(w => w.isActive);

  const withTotals = await Promise.all(active.map(async (w) => {
    const { total, fromMonth, hasTotal } = lastTotalForWorker(w, ym);
    const breakdown = await computePerformance(w);
    return { worker: w, total, fromMonth, hasTotal, performanceScore: breakdown.total };
  }));

  // Performance əmsalı üzrə sıralama (1. yer ən yüksək faiz)
  withTotals.sort((a, b) => {
    if (b.performanceScore !== a.performanceScore) return b.performanceScore - a.performanceScore;
    if (a.hasTotal && !b.hasTotal) return -1;
    if (!a.hasTotal && b.hasTotal) return 1;
    if (a.hasTotal && b.hasTotal && a.total !== b.total) return b.total - a.total;
    return `${a.worker.name} ${a.worker.surname}`.localeCompare(`${b.worker.name} ${b.worker.surname}`, 'az');
  });

  return withTotals.map((x, i) => ({
    workerId: x.worker.id,
    name: x.worker.name,
    surname: x.worker.surname,
    photo: x.worker.photo,
    position: x.worker.position,
    branch: x.worker.branch || '',
    rank: i + 1,
    total: x.total,
    fromMonth: x.fromMonth,
    hasTotal: x.hasTotal,
    performanceScore: x.performanceScore,
  }));
};

// ───────────────────── Branch leaderboard (filial reytinqi) ─────────────────────
export const getBranchLeaderboard = async (): Promise<BranchLeaderboardEntry[]> => {
  const ym = monthYM();
  const workers = await listWorkers();
  const active = workers.filter(w => w.isActive);
  const byBranch = new Map<string, { workerCount: number; totalSales: number; totalScore: number }>();

  // Hər aktiv işçi üçün performans əmsalını hesabla
  await Promise.all(active.map(async (w) => {
    const branchName = (w.branch || '').trim();
    if (!branchName) return; // filialı yoxsa nəzərə almırıq
    const { total } = lastTotalForWorker(w, ym);
    const breakdown = await computePerformance(w);
    const cur = byBranch.get(branchName) || { workerCount: 0, totalSales: 0, totalScore: 0 };
    cur.workerCount += 1;
    cur.totalSales += total || 0;
    cur.totalScore += breakdown.total || 0;
    byBranch.set(branchName, cur);
  }));

  const list = Array.from(byBranch.entries()).map(([name, v]) => ({
    name,
    workerCount: v.workerCount,
    totalSales: v.totalSales,
    avgPerformance: v.workerCount > 0 ? Math.round(v.totalScore / v.workerCount) : 0,
    rank: 0,
  }));
  // Filiallar orta performans əmsalına görə sıralanır (yüksəkdən aşağı)
  list.sort((a, b) => {
    if (b.avgPerformance !== a.avgPerformance) return b.avgPerformance - a.avgPerformance;
    return b.totalSales - a.totalSales;
  });
  list.forEach((x, i) => { x.rank = i + 1; });
  return list;
};

export type { Timestamp };
export { onSnapshot };
